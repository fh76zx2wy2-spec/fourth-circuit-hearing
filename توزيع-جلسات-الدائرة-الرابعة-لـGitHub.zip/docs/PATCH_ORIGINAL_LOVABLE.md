# تعديل المصدر الأصلي من Lovable — تعليمات دقيقة لكلود

**المطلوب الوحيد:** منع حذف التوزيع السابق عندما يزيد المستخدم عدد جلسات اليوم أو يضيف جلسة جديدة. لا تُعِد توزيع الموظفين الذين لديهم جلسات سابقة. يُمنع استبدال معرّفات الجلسات UUID وإعادة إنشاء عناصرها؛ الحفاظ على `id` و`clerk` و`originalClerk` لكل سجل موجود شرط أساسي حتى لا تتلف سجلات الاعتذارات في Supabase.

## موضع الخلل في الأصل

في `src/routes/index.tsx` كانت دالة `setCount` تقوم بالتالي عند أي تغيير للعدد:

```tsx
return { ...d, hearings: list.map(h => ({ ...h, clerk: null, originalClerk: null })), distributed: false };
```

وكانت دالة `removeRow` تفعل الشيء نفسه، فتزيل أسماء جميع الموظفين. **احذف هذا السلوك**. وتأكد من أن تغيير قيمة `countInput` لا يُفعّل توزيعًا جديدًا بأي طريقة.

## تعديل `setCount` المقترح

احتفظ بجميع الجلسات القديمة كما هي. عند الزيادة فقط، أضف صفوفًا جديدة. إذا كان اليوم موزعًا بالكامل، أسند كل صف جديد إلى الموظف النشط الأقل تكليفًا، مع كسر التعادل بحسب استحقاق العدالة الأسبوعية. إذا لم يوزَّع اليوم بعد، أضف صفوفًا `clerk: null`، دون تغيير القديم. عند تقليل العدد، احذف الصفوف الزائدة فقط **بعد التحذير عند الحاجة**، ودون إعادة توزيع الباقي.

يمكن إنشاء دالة نقية داخل `src/lib/history.ts`:

```ts
export function extendDayWithoutRedistribution(
  day: DayRecord, desiredCount: number,
  days: Record<string, DayRecord>, date: string,
  rng: () => number = Math.random,
): DayRecord {
  if (desiredCount <= day.hearings.length) return day;
  const hearings = [...day.hearings];
  const canAssign = day.distributed && day.active.length > 0 &&
    hearings.every(h => h.clerk !== null && day.active.includes(h.clerk));
  const debt = historicalDebt(days, date);
  while (hearings.length < desiredCount) {
    let chosen: string | null = null;
    if (canAssign) {
      const counts = Object.fromEntries(day.active.map(name =>
        [name, hearings.filter(h => h.clerk === name).length]
      )) as Record<string, number>;
      const min = Math.min(...day.active.map(name => counts[name] ?? 0));
      const leastLoaded = day.active.filter(name => counts[name] === min);
      const bestDebt = Math.min(...leastLoaded.map(name => debt[name] ?? 0));
      const eligible = leastLoaded.filter(name => (debt[name] ?? 0) === bestDebt);
      chosen = eligible[Math.floor(rng() * eligible.length)] ?? null;
    }
    hearings.push({ id: newId(), ...defaultTime(hearings.length), clerk: chosen, originalClerk: chosen });
  }
  return { ...day, hearings, distributed: canAssign };
}
```

وفي `src/routes/index.tsx`:

```tsx
const setCount = (n: number) => {
  const c = Math.min(MAX_COUNT, Math.max(MIN_COUNT, Math.round(n || 1)));
  setCountInput(String(c));
  setData(prev => {
    const existing = prev.days[prev.selectedDate] ?? blankDay();
    if (existing.hearings.length === c) return prev;
    const next = c < existing.hearings.length
      ? { ...existing, hearings: existing.hearings.slice(0, c) }
      : extendDayWithoutRedistribution(existing, c, prev.days, prev.selectedDate);
    return { ...prev, days: { ...prev.days, [prev.selectedDate]: next } };
  });
};

const removeRow = (id: string) => {
  if (hearings.length <= 1) return;
  updateDay(d => ({ ...d, hearings: d.hearings.filter(h => h.id !== id) }));
  setCountInput(String(hearings.length - 1));
};
```

حسّن كذلك حقل إدخال العدد بإلغاء إعادة التحجيم اللحظي لكل حرف: اجعل `onChange` يعدّل `countInput` فقط، وطبّق `setCount` على `onBlur` أو Enter. وحّد عملية الإضافة عبر الزر والحقل.

**حماية إضافية:** في دالة `draw` ضع تأكيدًا إن كان `distributed` صحيحًا حتى لا يحدث خلط يدوي غير مقصود:

```ts
if (distributed && !window.confirm(
  'سيُعاد توزيع جميع الجلسات وقد تتغير أسماء الموظفين. هل تريد المتابعة؟'
)) return;
```

## اختبارات إلزامية

- يوم موزّع 20 جلسة: إضافة جلسة واحدة تحفظ `id` و`clerk` و`originalClerk` للـ20، ويُسنَد الصف رقم 21 فقط.
- تغيير الوقت في الجلسة الجديدة لا يمس أي صف آخر.
- حذف جلسة لا يمس إسناد بقية الصفوف.
- إغلاق الصفحة وإعادة فتحها يُظهر نفس التوزيع المحفوظ من قاعدة البيانات.
- الضغط على «إعادة التوزيع» وحده هو الذي يسمح بتغيير جميع التكليفات، وبعد تحذير صريح.
- راعِ أن Supabase RPC `save_complete_day` يستخدم `expectedVersion` الصحيح وأن بيانات الاعتذارات تبقى مرتبطة بـ UUID الثابت.

**لا تغيّر التصميم أو أسماء الموظفين أو طريقة تسجيل الدخول أو هيكل قاعدة البيانات.**
